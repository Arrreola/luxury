<div class="msg-succes">
    <div class="msg-succes-square">
        <span class="msg-succes-heading">Copy en su version corta.</span>
        <p class="msg-succes-text">Aqui va un texto que hable acerca de la marca y unas cuantas cosas mas para lograr
            envolver al usuario y que realice una sita, para la compra de su colchonsin, aprotimadamente</p>
        <div id="map"></div>
        <span class="msg-succes-direccion">Direccion: direccion ,Monterrey, Nuevo Leon, Mexico</span>
    </div>
</div>